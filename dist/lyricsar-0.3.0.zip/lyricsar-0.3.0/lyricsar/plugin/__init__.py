__doc__="""plugin directory is use to store plugin of diffrent website \
inside a single directory"""

__all__=['google','lyricsmint']
