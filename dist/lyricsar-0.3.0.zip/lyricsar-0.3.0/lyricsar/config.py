__all__=['PLUGIN']
__doc__="""all config settings is stored in this dir"""

PLUGIN=["lyricsmint","azlyrics"]
