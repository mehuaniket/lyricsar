
PLUGIN=["lyricsmint","azlyrics"]
